from django.apps import AppConfig


class ScrapperConfig(AppConfig):
    name = 'scrapper'
